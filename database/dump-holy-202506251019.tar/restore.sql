--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1.pgdg120+1)
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE holy;
--
-- Name: holy; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE holy WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE holy OWNER TO admin;

\connect holy

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tbl_carousel; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.tbl_carousel (
    id integer NOT NULL,
    image_path text NOT NULL,
    title text,
    description text,
    is_active boolean DEFAULT true,
    display_order integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tbl_carousel OWNER TO admin;

--
-- Name: tbl_carousel_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.tbl_carousel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tbl_carousel_id_seq OWNER TO admin;

--
-- Name: tbl_carousel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.tbl_carousel_id_seq OWNED BY public.tbl_carousel.id;


--
-- Name: tbl_events; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.tbl_events (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    date date NOT NULL,
    image1 text,
    image2 text,
    image3 text,
    image4 text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tbl_events OWNER TO admin;

--
-- Name: tbl_events_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.tbl_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tbl_events_id_seq OWNER TO admin;

--
-- Name: tbl_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.tbl_events_id_seq OWNED BY public.tbl_events.id;


--
-- Name: tbl_feedback; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.tbl_feedback (
    id integer NOT NULL,
    name text NOT NULL,
    year text,
    occupation text,
    comment text,
    isapproved boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tbl_feedback OWNER TO admin;

--
-- Name: tbl_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.tbl_feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tbl_feedback_id_seq OWNER TO admin;

--
-- Name: tbl_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.tbl_feedback_id_seq OWNED BY public.tbl_feedback.id;


--
-- Name: tbl_carousel id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.tbl_carousel ALTER COLUMN id SET DEFAULT nextval('public.tbl_carousel_id_seq'::regclass);


--
-- Name: tbl_events id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.tbl_events ALTER COLUMN id SET DEFAULT nextval('public.tbl_events_id_seq'::regclass);


--
-- Name: tbl_feedback id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.tbl_feedback ALTER COLUMN id SET DEFAULT nextval('public.tbl_feedback_id_seq'::regclass);


--
-- Data for Name: tbl_carousel; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.tbl_carousel (id, image_path, title, description, is_active, display_order, created_at) FROM stdin;
\.
COPY public.tbl_carousel (id, image_path, title, description, is_active, display_order, created_at) FROM '$$PATH$$/3384.dat';

--
-- Data for Name: tbl_events; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.tbl_events (id, title, description, date, image1, image2, image3, image4, created_at) FROM stdin;
\.
COPY public.tbl_events (id, title, description, date, image1, image2, image3, image4, created_at) FROM '$$PATH$$/3382.dat';

--
-- Data for Name: tbl_feedback; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.tbl_feedback (id, name, year, occupation, comment, isapproved, created_at) FROM stdin;
\.
COPY public.tbl_feedback (id, name, year, occupation, comment, isapproved, created_at) FROM '$$PATH$$/3380.dat';

--
-- Name: tbl_carousel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.tbl_carousel_id_seq', 4, true);


--
-- Name: tbl_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.tbl_events_id_seq', 8, true);


--
-- Name: tbl_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.tbl_feedback_id_seq', 4, true);


--
-- Name: tbl_carousel tbl_carousel_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.tbl_carousel
    ADD CONSTRAINT tbl_carousel_pkey PRIMARY KEY (id);


--
-- Name: tbl_events tbl_events_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.tbl_events
    ADD CONSTRAINT tbl_events_pkey PRIMARY KEY (id);


--
-- Name: tbl_feedback tbl_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.tbl_feedback
    ADD CONSTRAINT tbl_feedback_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

